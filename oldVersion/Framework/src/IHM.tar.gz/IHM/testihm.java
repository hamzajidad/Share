package IHM;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class testihm extends JFrame{
    static JPanel nav_bar_panel;
    JButton home;
    JButton back;
    JButton forward;
    Home_Panel currentPanel;

    static Stack<JPanel> previousPanels;
    static Stack<JPanel> forwardPanels;

    public testihm(){
       
        setSize(800,600);
        setLayout(new BorderLayout());
        setVisible(true);

        add(nav_bar(), BorderLayout.NORTH);
        currentPanel = init_display();
        add(currentPanel, BorderLayout.CENTER);

        previousPanels = new Stack<JPanel>();
        forwardPanels  = new Stack<JPanel>();
    }

    private JPanel nav_bar(){
        ButtonPressHandler handler = new ButtonPressHandler();

        nav_bar_panel = new JPanel();
        back = new JButton("Back");
        back.addActionListener((ActionListener) handler);
        home = new JButton("Home");
        home.addActionListener(handler);
        forward = new JButton("Forward");
        forward.addActionListener(handler);

        nav_bar_panel.add(back);
        nav_bar_panel.add(home);
        nav_bar_panel.add(forward);

        return nav_bar_panel;
    }

    private Home_Panel init_display(){
        Home_Panel home_panel = new Home_Panel();

        return home_panel;
    }

    public void change_display(JPanel myPanel){
        invalidate();
        remove(currentPanel);
        previousPanels.push(currentPanel);
        currentPanel = myPanel;
        add(currentPanel);
        validate();
    }

    public void previous_display(){
        if(!previousPanels.empty()){
            invalidate();
            remove(currentPanel);
            forwardPanels.push(currentPanel);
            currentPanel = previousPanels.pop();
            add(currentPanel);
            validate();
        }
    }

    public void forward_display(){
        if(!forwardPanels.empty()){
            invalidate();
            remove(currentPanel);
            previousPanels.push(currentPanel);
            currentPanel = forwardPanels.pop();
            add(currentPanel);
            validate();
        }
    }

    private class ButtonPressHandler implements ActionListener 
       {
          public void actionPerformed( ActionEvent event )
          {
              if(event.getSource() == back){
                  previous_display();
                  System.out.print("You selected back");
              } else if(event.getSource() == forward){
                  forward_display();
                  System.out.print("You selected forward");
              }
          }

		public void actionPerformed1(ActionEvent e) {
			// TODO Auto-generated method stub
			
		} // end method actionPerformed
       } 

}
