
public interface Controllable {

}
